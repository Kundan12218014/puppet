document.addEventListener("DOMContentLoaded", loadTasks);

function loadTasks() {
  const tasks = JSON.parse(localStorage.getItem("tasks")) || [];
  tasks.forEach(task => renderTask(task.text, task.completed));
}

function saveTasks() {
  const tasks = [];
  document.querySelectorAll("#todo-list li").forEach(li => {
    tasks.push({
      text: li.querySelector("span").innerText,
      completed: li.classList.contains("completed")
    });
  });
  localStorage.setItem("tasks", JSON.stringify(tasks));
}

function addTask() {
  const input = document.getElementById("todo-input");
  const text = input.value.trim();
  if (text !== "") {
    renderTask(text);
    input.value = "";
    saveTasks();
  }
}

function renderTask(text, completed = false) {
  const li = document.createElement("li");
  if (completed) li.classList.add("completed");

  const span = document.createElement("span");
  span.innerText = text;
  span.style.cursor = "pointer";
  span.onclick = () => {
    li.classList.toggle("completed");
    saveTasks();
  };

  const delBtn = document.createElement("button");
  delBtn.innerText = "Delete";
  delBtn.onclick = () => {
    li.remove();
    saveTasks();
  };

  li.appendChild(span);
  li.appendChild(delBtn);
  document.getElementById("todo-list").appendChild(li);
}

function clearTasks() {
  document.getElementById("todo-list").innerHTML = "";
  localStorage.removeItem("tasks");
}

