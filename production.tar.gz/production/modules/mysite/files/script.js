function showAlert() {
  alert("Thanks for trying SmartApp! 🚀");
}

