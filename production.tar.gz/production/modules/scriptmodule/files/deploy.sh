#!/bin/bash
echo "Deployment script running!" > /opt/deployment.log
