const apiKey = '584b04f65d5b0d097eafccdf312bcba1';  // Your API Key
let searchHistory = [];

document.getElementById("cityInput").addEventListener("keypress", function (e) {
  if (e.key === "Enter") {
    getWeather();
  }
});

async function getWeather() {
  const city = document.getElementById('cityInput').value.trim();
  if (!city) return;

  const url = `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${apiKey}&units=metric`;
  const loadingEl = document.getElementById('loading');
  loadingEl.innerText = "Loading...";

  try {
    const response = await fetch(url);
    const data = await response.json();
    loadingEl.innerText = "";

    if (data.cod === 200) {
      const weatherHtml = `
        <h2>${data.name}, ${data.sys.country} <img src="https://flagcdn.com/24x18/${data.sys.country.toLowerCase()}.png"></h2>
        <img src="https://openweathermap.org/img/wn/${data.weather[0].icon}@2x.png" class="weather-icon" alt="${data.weather[0].description}">
        <p>🌡️ Temperature: ${data.main.temp}°C</p>
        <p>🌤️ Weather: ${data.weather[0].description}</p>
        <p>💧 Humidity: ${data.main.humidity}%</p>
        <p>💨 Wind Speed: ${data.wind.speed} m/s</p>
      `;
      document.getElementById('weatherResult').innerHTML = weatherHtml;
      updateSearchHistory(data.name);
    } else {
      document.getElementById('weatherResult').innerHTML = `<p>${data.message}</p>`;
    }
  } catch (error) {
    loadingEl.innerText = "";
    document.getElementById('weatherResult').innerHTML = `<p>Error fetching weather data.</p>`;
  }
}

function updateSearchHistory(city) {
  if (!searchHistory.includes(city)) {
    searchHistory.unshift(city);
    if (searchHistory.length > 5) {
      searchHistory.pop();
    }
  }

  let historyHtml = "<strong>Search History:</strong><br>";
  searchHistory.forEach((c, i) => {
    historyHtml += `${i + 1}. ${c}<br>`;
  });

  document.getElementById('searchHistory').innerHTML = historyHtml;
}

